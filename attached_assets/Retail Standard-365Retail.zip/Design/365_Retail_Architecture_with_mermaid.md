# 365 Retail Architecture

## Technical Architecture Diagram
(Images from original PDF not embedded in text extraction.)

## Dependency of Services on Different Applications
- **ADM**: reportapi, backgroundapi, schedulerapi, compile-price-api, platformapi
- **V5/RT**: kskapi, cafeapi, printapi, payapi, dashapi, g2api, msgapi, salesapi
- **365Pay**: sssapi, platformapi
- **MMA (nano, pico, micro)**: sssapi
- **SOSLoad**: —
- **Dining**: —

## Major Services in 365 Retail
- **365Pay**: Interface for global market account. Hosted in S3 & CloudFront.
- **smtmail**: Email notification server for ADM.
- **smtnotify**: Notification gateway for Slack, email, SMS.
- **dashweb**: Kiosk monitoring web app.
- **g2api**: Migrates data from Gen2 to sosdb.
- **heatwave**: Filters barcode scanner events on V5 kiosk.
- **g2convert**: Gen2 to sosdb conversion.
- **capadm**: Operator admin portal.
- **capsvr**: Processes sales, transactions & sync.
- **sosload**: Tool for loading products & accounts.
- **dashapi**: Backend for dashweb.
- **sssapi**: Backend for nano tablets.
- **receiptapi**: Sends receipts via email/SMS.
- **eftbatchapi**: EFT & GMA reporting service.
- **payapi**: Payment gateway.
- **printapi**: Receipt printing.
- **cafeapi**: CKDS ticket creation for dining.
- **kskapi**: Backend for kiosks.
- **scheduleapi**: Scheduling tasks.
- **reportapi**: Reporting.
- **backgroundapi**: Long-running tasks.
- **vdiapi**: 3rd party product update integration.
- **msgapi**: Messaging layer.
- **aviapi**: AVI product sync.
- **lsaapi**: Lightspeed Inventory API.
- **difapi**: Multi-market sync.
- **salesapi**: Order service backend.
- **httpd**: Proxy server.
- **AmazonMQ**: Broker endpoint.
- **swarmcmd**: Async proxy to kiosks.
- **compile-prices-api**: Pricing compilation.
- **monnitapi**: —
- **pricing-inquiry-api**: Real-time pricing search.
- **alertapi**: Offline/no-sale alerts.

## ADM & ReportAPI Flow
- User schedules report in ADM.
- capadm stores schedule → converts cron → CloudWatch rule.
- CloudWatch triggers Lambda.
- Lambda calls Report Builder microservice.

## EFT Disbursement Report
- Used by Finance for operator payments.
- Performs variance checks (>10% deviation).
- UI: Super > Finance > EFT Disbursement.

(Additional pages contained diagrams only.)


---

## Mermaid diagrams

> These diagrams are written in [Mermaid](https://mermaid.js.org/). GitHub, Azure DevOps, and many docs sites render Mermaid blocks automatically.

### 1) System Context (High‑Level)
```mermaid
flowchart LR
  %% Subsystems
  subgraph Devices
    V5RT["V5/RT Kiosks"]
    MM6["MM6 / Nano / Pico"]
  end

  subgraph Mobile
    APP365["365Pay (Web/Mobile)"]
  end

  subgraph BackOffice["Back Office Services"]
    ADM["capadm (ADM)"]
    KSKAPI["kskapi"]
    SSSAPI["sssapi"]
    CAPSVR["capsvr"]
    PAYAPI["payapi"]
    CAFEAPI["cafeapi"]
    PRINTAPI["printapi"]
    DASHAPI["dashapi"]
    REPORTAPI["reportapi"]
    BKGAPI["backgroundapi"]
    SCHEDAPI["schedulerapi"]
    COMPILEPRICE["compile-prices-api"]
    PRICEINQ["pricing-inquiry-api"]
    RECEIPTAPI["receiptapi"]
    EFTBATCH["eftbatchapi"]
    MSGAPI["msgapi"]
    SWARM["swarmcmd"]
  end

  subgraph Infra["Platform/Infra"]
    MQ["AmazonMQ"]
    CW["AWS CloudWatch Events"]
    LAMBDA["Build Report Lambda"]
  end

  subgraph Data["Data Stores"]
    SOSDB[("SOSDB")]
    PRICINGREC[("pricingrec")]
  end

  %% Device flows
  V5RT --> MSGAPI --> KSKAPI
  MM6 --> SSSAPI
  SWARM --> KSKAPI
  SWARM --> SSSAPI
  KSKAPI --> CAPSVR
  SSSAPI --> CAPSVR
  CAPSVR --> SOSDB
  CAPSVR --> PAYAPI
  CAPSVR --> RECEIPTAPI

  %% ADM & reporting
  ADM --> REPORTAPI
  ADM --> SCHEDAPI --> BKGAPI
  SCHEDAPI --> CW --> LAMBDA --> REPORTAPI
  REPORTAPI --> SOSDB
  BKGAPI --> SOSDB

  %% Pricing
  COMPILEPRICE --> PRICINGREC
  PRICEINQ --> PRICINGREC

  %% Finance/EFT
  EFTBATCH --> SOSDB
```

### 2) Application → Dependency Map
```mermaid
graph LR
  subgraph Apps
    ADM_APP[ADM]
    V5RT_APP[V5/RT]
    PAY_APP[365Pay]
    MMA_APP[MMA (nano/pico/micro)]
  end

  REPORTAPI[reportapi]
  BKG[backgroundapi]
  SCHED[schedulerapi]
  COMPILE[compile-price-api]
  PLATFORM[platformapi]

  KSK[kskapi]
  CAFE[cafeapi]
  PRINT[printapi]
  PAY[payapi]
  DASH[dashapi]
  G2[g2api]
  MSG[msgapi]
  SALES[salesapi]
  SSS[sssapi]

  ADM_APP --> REPORTAPI
  ADM_APP --> BKG
  ADM_APP --> SCHED
  ADM_APP --> COMPILE
  ADM_APP --> PLATFORM

  V5RT_APP --> KSK
  V5RT_APP --> CAFE
  V5RT_APP --> PRINT
  V5RT_APP --> PAY
  V5RT_APP --> DASH
  V5RT_APP --> G2
  V5RT_APP --> MSG
  V5RT_APP --> SALES

  PAY_APP --> SSS
  PAY_APP --> PLATFORM

  MMA_APP --> SSS
```

### 3) ADM → Report Scheduling Flow
```mermaid
sequenceDiagram
  actor User as Operator
  participant ADM as ADM (capadm)
  participant SCHED as schedulerapi
  participant CW as AWS CloudWatch
  participant L as Build Report Lambda
  participant RB as Report Builder svc
  participant RPT as reportapi

  User->>ADM: Create & schedule report
  ADM->>SCHED: Persist schedule & cron
  SCHED->>CW: Create rule + target (input JSON)
  CW-->>L: Trigger on schedule
  L->>RB: Call with scheduleId + tz
  RB->>RPT: Build/assemble report
  RPT-->>User: Deliver/notify
```

### 4) Kiosk → SOSDB Sales Flow
```mermaid
sequenceDiagram
  participant Kiosk as V5/RT Kiosk
  participant MSG as msgapi
  participant KSK as kskapi
  participant CAP as capsvr
  database SOS as SOSDB
  participant RCP as receiptapi

  Kiosk->>MSG: Scan items / checkout
  MSG->>KSK: Forward events/requests
  KSK->>CAP: Submit order/payment
  CAP->>CAP: Price/Tax/Validate
  CAP->>SOS: Persist sale (hdr/detail/payment)
  CAP->>RCP: Send receipt (email/SMS)
```

### 5) EFT Disbursement Variance (10% threshold)
```mermaid
sequenceDiagram
  actor Finance as Finance User
  participant ADM as ADM (EFT UI)
  participant EFT as eftbatchapi
  database HIST as SOSDB (historical)

  Finance->>ADM: Open Disbursement for Date D
  ADM->>EFT: Request variance for D
  EFT->>HIST: Fetch current batch D
  EFT->>HIST: Fetch historical batches
  EFT-->>ADM: Variance results (flag >10%)
  ADM-->>Finance: Display variance table
```

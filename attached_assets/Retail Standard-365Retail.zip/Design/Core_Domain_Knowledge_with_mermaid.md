# Core Domain Knowledge and Business Rules

## 1. Core Domain Concepts
- Unattended Retail & Foodservice
- Devices & Software (V5, RT, MM6, Nano, Pico, Dining)
- ADM Back Office
- Databases (SOSDB, KSKDB)

---
# Mermaid Diagrams

## 1. Project Lifecycle (In‑House Alpha → Field Trial → GA)
```mermaid
flowchart LR
  A[Idea / Intake] --> B[Sizing & Analysis]
  B --> C[In-House Alpha]
  C --> D[Field Trial]
  D --> E[GA Release]
```

## 3. Payment Tender Priority Flow
```mermaid
flowchart TD
  Start([Start Payment]) --> CheckExtAccount{External Account Active?}
  CheckExtAccount -->|Yes| BalCheck{Sufficient Balance?}
  CheckExtAccount -->|No| RouteOther[Tender Routing]
  BalCheck -->|Yes| Approve[Approve & Debit]
  BalCheck -->|No| SplitOrDecline[Split Tender or Decline]
```

## 4. Store-and-Forward / Offline Payment Flow
```mermaid
sequenceDiagram
  participant Kiosk
  participant Queue as Offline Queue
  participant EFT as EFTBatch

  Kiosk->>Queue: Store transaction offline
  Queue-->>EFT: Sync when network returns
  EFT->>EFT: Validate & Process
```

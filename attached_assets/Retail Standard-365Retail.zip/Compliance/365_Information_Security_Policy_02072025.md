# 365 Information Security Policy (02-07-2025)

> Converted from PDF to Markdown.

## Contents
- I. Policy
- II. Scope
- III. Information Security Responsibilities
- IV. Information Classifications
  - A. Protected Health Information (PHI)
  - B. Personally Identifiable Information (PII)
  - C. PCI
  - D. Confidential Information (CI)
  - E. Internal Information
  - F. Public Information
- V. Risk Management
  - A. Existing Systems
  - B. New Systems
  - C. Annual Risk Assessment
- VI. Computer and Information Control
  - A. Ownership of Software
  - B. Installed Software
  - C. Patch Management
  - D. Malware Protection
  - E. Access Controls
    - 1. Authorization
    - 2. Identification/Authentication
    - 3. Password Policy
    - 4. Expiration
  - F. Remote Access Tool Policy
  - G. Data Integrity
  - H. Data Storage and Transmission
    - 1. Secure Transmission
    - 2. Storage Guidelines
  - I. Physical Access
    - 1. Building Security
  - J. Equipment and Media Controls
  - K. Removable Media
  - L. POS/Workstation Decommission and Reuse Policy
  - M. Other Media Controls
- VII. Training and Awareness
- VIII. Network Security Policy
- IX. Communication Policy
- X. Clean Desk Policy
- XI. Vendor Management
- XII. PCI Policy
- XIII. PHI Policy
- XIV. Change Management
  - A. Roles and Responsibilities
  - B. Change Management Steps
- XV. Remote Employee Policy
- XVI. Application Security Architecture Policy
- XVII. Encryption Management
- XVIII. Contingency Plan
- XIX. IT Asset End of Life Disposal Policy
- XX. Systems Audit
- XXI. Policy Audit
- XXII. Document Revisions
- XXIII. Definitions and Acronyms

---

## I. Policy
It is the policy of 365 RETAIL MARKETS that information, in all its forms—written, spoken, recorded electronically or printed—will be protected from accidental or intentional unauthorized modification, destruction or disclosure throughout its life cycle. This protection includes an appropriate level of security over the equipment and software used to process, store, and transmit that information.

All policies and procedures must be documented and made available to individuals responsible for their implementation and compliance. All activities identified by the policies and procedures must also be documented. All the documentation, which may be in electronic form, must be retained for at least **5 (five) years** after initial creation, or, pertaining to policies and procedures, after changes are made, unless otherwise required by law. All documentation must be periodically reviewed for appropriateness and currency, a period to be determined by each entity within 365 RETAIL MARKETS.

At each entity and/or department level, additional policies, standards, and procedures will be developed detailing the implementation of this policy and addressing any additional information systems in such entity and/or department. All departmental policies must be consistent with this policy. All systems implemented after the effective date of these policies are expected to comply with the provisions of this policy where possible. Existing systems are expected to be brought into compliance where possible and as soon as practical.

## II. Scope
The scope of information security includes the protection of confidentiality, integrity and availability of information. The framework for managing information security in this policy applies to all 365 RETAIL MARKETS entities, subsidiaries, employees, contractors, and other involved persons, and all involved systems throughout 365 RETAIL MARKETS. This policy and all standards apply to all protected health information and other classes of protected information in any form as defined below in **Information Classification**.

## III. Information Security Responsibilities
**Information Security Team (IST):** Responsible for policies, controls, education, audits, and compliance with applicable laws (e.g., **GDPR, CCPA, CPRA, FCRA, HIPAA, BIPA, GLBA**). Responsibilities include advising on classification, embedding controls from design to production, employee education, performing audits, and reporting to management.

**Information Owner:** Manager responsible for creation/primary use of information. Sets retention, ensures protection, authorizes access, specifies controls, reports loss/misuse, and initiates corrective actions.

**Custodian:** Operates storage/processing of information and administers controls set by the owner. Provides safeguards, administers access, maintains policies, promotes awareness, reports incidents, and responds to them.

**User Management:** Supervises users and oversees appropriate access, initiates changes, terminates/updates access on role changes, provides training, and reports incidents.

**User:** Any authorized person accessing information. Must access only as needed, comply with policies and controls, protect authentication secrets, report incidents, and log off/secure systems when away.

## IV. Information Classifications
Information must be classified by sensitivity. The same classification applies across all formats.

### A. Protected Health Information (PHI)
Definition aligns to healthcare data created/received by covered entities, relating to health condition, care, or payment, including identifiable demographics. Unauthorized disclosure may violate law and cause harm.

### B. Personally Identifiable Information (PII)
Information that identifies or is linkable to a consumer/household (e.g., names, addresses, IDs, IPs, biometrics, geolocation, employment/education data, profiles, etc.).

### C. PCI
Applies to organizations storing/processing/transmitting **cardholder data (CHD)** and/or **sensitive authentication data (SAD)**.

### D. Confidential Information (CI)
Highly sensitive non‑PHI/PII/PCI information (e.g., ACH, bank numbers, proprietary info, passwords, encryption keys). Unauthorized disclosure may violate laws and/or cause significant harm.

### E. Internal Information
Intended for unrestricted internal use; may be shared within 365 or partners. Examples include directories and internal policies. Default classification if not otherwise specified.

### F. Public Information
Approved for public release by designated authority (e.g., marketing brochures, website content).

## V. Risk Management
Periodic analysis of threats, vulnerabilities, and asset values to determine risks to confidentiality, integrity, and availability.

### A. Existing Systems
Subject to regular assessments (e.g., **ASV scans – quarterly; Pen Test – yearly; External/Internal vulnerability scans – quarterly**). Risks are rated (Critical, High, Medium, Low, Best Practice) and remediated via Change Management and SDLC.

### B. New Systems
Evaluated through Change Management; secure configurations applied by default.

### C. Annual Risk Assessment
Initiated by IST using 365’s baseline drawn from **PCI DSS, SOC 2, NIST CSF, ISO‑27001**. Risk register maintained with probability/likelihood.

## VI. Computer and Information Control
Systems and information are company assets and must be protected.

### A. Ownership of Software
Software developed/licensed for 365 remains 365 property and must respect licenses.

### B. Installed Software
Must comply with licenses and be formally approved by IST. Unapproved software handling PHI/PII/PCI/CI/Internal is prohibited.

### C. Patch Management
All systems storing Information must receive regular security patches.

### D. Malware Protection
IST‑approved multi‑layered protection; users may not disable protections; definitions auto‑update.

### E. Access Controls
Access to sensitive information is controlled.

#### 1. Authorization
Need‑to‑know; context‑, role‑, or user‑based access models.

#### 2. Identification/Authentication
Unique IDs; strong authentication (passwords/biometrics/tokens). **MFA** and **location‑based restrictions** where feasible; **SSO** recommended. Auto timeouts (≤15 min) and session security.

#### 3. Password Policy
- Minimum length: **9**
- Require symbols, numbers, upper & lower case
- Expire after **90 days**; prevent reuse of **7** previous
- Lockout after **5** failed attempts

#### 4. Expiration
Quarterly audits; disable inactive accounts (>90 days).

### F. Remote Access Tool Policy
Least privilege, **MFA**, location restrictions, posture checks, logging, timeouts, and SSO are mandatory.

### G. Data Integrity
Use audits, RAID, ECC, checksums, encryption, and digital signatures to ensure integrity.

### H. Data Storage and Transmission
#### 1. Secure Transmission
Use **TLS/SSL/IPsec**, encrypted email (PGP/S/MIME), SFTP, and secure file sharing. Avoid unencrypted channels (email/SMS/IM). Use encrypted links/password protected archives when sharing externally.

#### 2. Storage Guidelines
Store sensitive data only in secure, encrypted, approved systems; protect backups; prohibit storage in email, personal devices, or unapproved cloud; follow retention and secure disposal.

### I. Physical Access
Restrict access to processing areas; secure workstations; use auto‑logout; implement building security with badges, cameras (≥30‑day retention), visitor logs (≥1 year), and controlled server rooms.

### J. Equipment and Media Controls
Maintain accountability records; back up before moves; define disposal & reuse procedures.

### K. Removable Media
Do not store sensitive data on removable media unless explicitly approved and controlled.

### L. POS/Workstation Decommission and Reuse Policy
Wipe and destroy or reimage appropriately; reformat alone is insufficient.

### M. Other Media Controls
Mobile devices must have passwords, auto‑lock, and encryption; never leave unattended; strictly control mass data transfers and printing; avoid discussing sensitive info in public.

## VII. Training and Awareness
Provide regular (≥ quarterly) training and simulations; run activities during National Cyber Security Awareness month.

## VIII. Network Security Policy
Firewalls, segmentation, IDS/IPS with central logging, disable unnecessary services, patch network devices, prohibit internet/email on CHD systems, use strong Wi‑Fi encryption, and control third‑party/unauthorized devices on sensitive networks.

## IX. Communication Policy
Employees represent the company online; rules prohibit spam, harassment, forged headers, chain letters, newsgroup spam, PAN sharing via messaging, and forwarding to personal email.

## X. Clean Desk Policy
Lock workstations, shut down daily, secure cabinets/keys, avoid sticky‑note passwords, promptly pick printouts, shred/dispose securely, erase whiteboards, secure portable devices and media.

## XI. Vendor Management
All vendors must go through the Vendor Management Program with defined security controls.

## XII. PCI Policy
Never store **SAD**; never store full **PAN**. Use **E2EE/P2PE** for POS, tokenization for internet systems, and store only encrypted SAD for offline store‑and‑forward. Annual **PCI‑DSS** assessment by independent QSA. Individuals handling CHD must follow strict rules.

## XIII. PHI Policy
Systems and individuals handling PHI must follow FullCount & 365 HIPAA Privacy/Security policies and procedures.

## XIV. Change Management
Documented process with Change Manager, Initiator, CAB, Roadmap Committee, and Implementation Team. Steps include request, evaluation, planning, CAB approval, implementation via Impact Analysis & roadmap, and closure.

## XV. Remote Employee Policy
Remote workers must use VPN with IP whitelisting and MFA to access Information systems.

## XVI. Application Security Architecture Policy
Applies to systems and individuals planning/designing/developing/testing/deploying. Covers security architecture, deployment, input validation, authN/Z, session & config management, crypto, parameter handling, exceptions, auditing, logging, frameworks, static/dynamic analysis, encryption in transit/at rest, patching, retiring deprecated services, secure APIs, and fraud prevention.

## XVII. Encryption Management
Encrypt sensitive data at rest and in transit; separate key and data access; log key usage; use **AES‑256**; use **HSM/KMS** (FIPS 140‑2 validated); define key lifecycles based on sensitivity and exposure.

## XVIII. Contingency Plan
Define and maintain data backup, disaster recovery, and emergency operations plans; periodically test and revise; assess application/data criticality.

## XIX. IT Asset End of Life Disposal Policy
All IT assets (kiosks, POS, readers, workstations, servers, network gear, printers, etc.) must follow formal disposal policy.

## XX. Systems Audit
IST performs yearly audits of systems that store/process sensitive data; track remediation via Change Management.

## XXI. Policy Audit
IST performs yearly review of this policy; changes tracked via Change Management and documented in Document Revisions.

## XXII. Document Revisions
| Version | Change Log |
|---|---|
| 021016 | Original policy |
| 072418 | Updates to Title Page and document footer |
| 021419 | Updated: Risk Management, Information Classification, Information Security Definitions, Computer and Information Control, Scope. Added: ToC, Document Revisions, Remote Employee, Change Management, PCI, Network Security, Secure Coding, POS Decommission/Reuse, Systems Audit, Policy Audit |
| 02032021 | Updated: Policy, Responsibilities, PII, Transmission Security, Equipment Media Controls, Network Security, PCI, Change Management. Added: Patch Management |
| 10082021 | Added: Password Policy |
| 11132021 | Renamed/updated: Application Security Architecture Policy |
| 12202021 | Renamed/updated: Application Security Architecture Policy |
| 09262022 | Minor grammar; Updated: VI. Controls; Added: Training & Awareness, Communication, Clean Desk, Vendor Management |
| 10242023 | Minor grammar; Updated: V. Risk, VI. Controls, XV. AppSec Arch; Added: XII. PHI Policy, XVIII. IT Asset EoL |
| 02072025 | Minor grammar; Updated: IV. Classification, V. Risk, VI. Controls, XVI. AppSec Arch; Added: ToC |

## XXIII. Definitions and Acronyms
IST, ASV, QSA, Pen (Penetration Test), CVSS, SDLC, CAB, PCI, PHI, PII, CI, CHD, SAD, PAN, PCI‑DSS, Epic, Affiliated Covered Entities, Availability, HIPAA, Entity, 365 Platforms.
